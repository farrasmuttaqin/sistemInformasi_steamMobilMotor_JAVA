/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author farras
 */
public class Customer {
    
    public String nama;
    public String noTelp;
    public String alamat;
    
    public Customer(String _nama, String _noTelp, String _alamat)
    {
        nama=_nama;
        noTelp=_noTelp;
        alamat=_alamat;
    }
    
    public String getNama()
    {
        return nama;
    }
    public String getNoTelp()
    {
        return noTelp;
    }
    public String getAlamat()
    {
        return alamat;
    }
}
