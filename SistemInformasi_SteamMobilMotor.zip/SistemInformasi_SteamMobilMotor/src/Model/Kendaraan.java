/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author farras
 */
public class Kendaraan {
    
    public String noPlat;
    public String merk;
    public String model;
    public String jenis;
    
    public Kendaraan(){}
    
    public Kendaraan(String _noPlat, String _merk, String _model, String _jenis)
    {
        noPlat=_noPlat;
        merk=_merk;
        model=_model;
        jenis=_jenis;
    }
    
    public String getNoPlat()
    {
        return noPlat;
    }
    public String getMerk()
    {
        return merk;
    }
    public String getModel()
    {
        return model;
    }
    public String getJenis()
    {
        return jenis;
    }
}
