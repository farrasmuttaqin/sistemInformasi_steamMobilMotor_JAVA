/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

/**
 *
 * @author farras
 */
public class ControlPembayaranCustomer {
    public Control.DAO d = new Control.DAO();
    
    public ControlPembayaranCustomer(){}
    
    public void bayarKK(String _noHp,String _noPlat)
    {
            d.makeConnection();
            d.pembayaranKendaraanC(_noHp,_noPlat);
            d.closeConnection();
    }
}
