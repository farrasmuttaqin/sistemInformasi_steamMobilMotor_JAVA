/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;
import java.util.*;
import java.text.*;
import Model.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author farras
 */
public class DAO {
    public DAO(){}
    
    public static Connection con;
    public static final String url = "jdbc:ucanaccess://";
    public static final String path = "Y:/"+"Database/"+"tugasBesar.accdb";
    public static int tampung;
    public static int tampungA;
    public static String tampungPlatK;
    public static String tampungMerkK;
    public static String tampungModelK;
    public static String tampungJenisK;
    
    public void makeConnection(){
        System.out.println("Opening database...");
        try{
            con = DriverManager.getConnection(url+path);
            System.out.println("Success !\n");
        }
        catch(Exception Ex){
            System.out.println("Error Opening the database...\n");
            System.out.println(Ex);
        }
    }

    public void closeConnection(){
        System.out.println("Closing database...");
        try{
            con.close();
            System.out.println("Success !\n");
        }
        catch(Exception Ex){
            System.out.println("Error Closing the database...\n");
            System.out.println(Ex);
        }
    }
    
    public void insertKendaraan(Kendaraan o){
        int IDK = 0;
        int IDC = 0;
        int b = 0;
        String tampungPlat="";
        String tampungJenis="";
        String tampungMerk="";
        String tampungModel="";
        
        int tampungIDK=0;
        int tampungIDC=0;
        
        View.VInputPencucian oo = new View.VInputPencucian();
        
        String find = "SELECT * FROM Kendaraan";
        String findC = "select * from Customers";
        String findPlat = "SELECT * FROM Kendaraan WHERE Nomor_Plat= ? ";
        System.out.println("Inserting Kendaraan's Data...");
        try{
            PreparedStatement statementFind = con.prepareStatement(find);
            PreparedStatement statementFindPlat=con.prepareStatement(findPlat);
            PreparedStatement statementFindC=con.prepareStatement(findC);
            statementFindPlat.setString(1, o.getNoPlat());
            ResultSet rsPlat = statementFindPlat.executeQuery();
            ResultSet rsFind = statementFind.executeQuery();
            ResultSet rsFindC = statementFindC.executeQuery();
            while (rsFindC.next())
            {
                tampungIDC=rsFindC.getInt("ID_Customer");
            }
            while (rsFind.next())
            {
                tampungIDK=rsFind.getInt("ID_Kendaraan");
            }
            while (rsPlat.next())
            {
                b=1;
                tampungPlat=rsPlat.getString("Nomor_Plat");
                tampungMerk=rsPlat.getString("Merk");
                tampungModel=rsPlat.getString("Model");
                tampungJenis=rsPlat.getString("Jenis");
            }
            IDK = tampungIDK+1;
            IDC = tampungIDC+1;
            tampung = b;
            if (b==1)
                {
                    if(oo.getPlatT().equals(tampungPlat)&&oo.getMerkT().equals(tampungMerk)&&oo.getModelT().equals(tampungModel)&&oo.getJenisT().equals(tampungJenis))
                    {
                        JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan Tersebut Telah Terdaftar Pada Database","Peringatan!!",JOptionPane.INFORMATION_MESSAGE);
                        JOptionPane.showMessageDialog(null, "Pastikan Kendaraan Tersebut Telah Melakukan Pembayaran Jasa Pencucian Kendaraannya Sebelum Dilakukan Pencucian Kembali","Peringatan!! (Untuk Menghindari Ketidak-Akuratan Data)",JOptionPane.INFORMATION_MESSAGE);
                        int y=JOptionPane.showConfirmDialog(null, "Cuci Kendaraan Lagi?","Konfirmasi",JOptionPane.YES_NO_OPTION);
                        if (y==0)
                        {
                            String sqlCus="insert into Customers(ID_Customer,Nama,Nomor_Telp,Alamat) Values ('"+IDC+"','"+"Bukan Member','"+"-','"+"-')";
                            String sqp="insert into Kendaraan(ID_Kendaraan,ID_Customer,Nomor_Plat,Merk,Model,Jenis) Values('"+IDK+"','"+IDC+
                                    "','"+o.getNoPlat()+"','"+o.getMerk()+"','"+o.getModel()+"','"+o.getJenis()+"')";
                            Statement sSQP = con.createStatement();
                            int resC = sSQP.executeUpdate(sqlCus);
                            int rSQP = sSQP.executeUpdate(sqp);
                            JOptionPane.showMessageDialog(null, "Selamat Data Kendaraan Berhasil Dimasukkan Kembali Kedalam Database Pencucian");
                            sSQP.close();
                        }
                        else {}
                    }
                    else JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan = "+tampungPlat+" Tidak Sesuai Dengan Data Kendaraannya!!! Yaitu : Merk Kendaraan =  '"+tampungMerk+"'    Model Kendaraan = '"+tampungModel+"'    Jenis Kendaraan = '"+tampungJenis+"'","Kesalahan Pada Penginputan Data Kendaraan!!",JOptionPane.ERROR_MESSAGE);
                } 
            else
                {
                    String sqlC="insert into Customers(ID_Customer,Nama,Nomor_Telp,Alamat,Tanggal_Daftar) Values ('"+IDC+"','"+"Bukan Member','"+"-','"+"-','"+"-')";
                    String sql="INSERT INTO Kendaraan(ID_Kendaraan,ID_Customer,Nomor_Plat,Merk,Model,Jenis) VALUES('"+IDK+"','"+IDC+"','"+o.getNoPlat()+"','"+
                    o.getMerk()+"','"+o.getModel()+"','"+o.getJenis()+"')";
                    Statement statement=con.createStatement();
                    int resultC=statement.executeUpdate(sqlC);
                    int result=statement.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null, "Selamat Data Kendaraan Berhasil Dimasukkan kedalam database");
                    System.out.println("Success\n");
                    statement.close();
                }
            statementFindPlat.close();
            statementFind.close();
            statementFindC.close();
        }
        catch(Exception Ex){
            System.out.println("Error inserting Kendaraan's data...\n");
            System.out.println(Ex);
        }
    }
    
    public void insertKendaraanC(Kendaraan o,String _nomor){
        int b = 0;
        int a = 0;
        int s=0;
        int si=0;
        int tamp=0;
        
        String tampungPlat="";
        String tampungJenis="";
        String tampungMerk="";
        String tampungModel="";
        
        int tampungIDK=0;
        int IDK=0;
        String tampungC="";
        int tampungK=0;
        int tampungUK=0;
        
        View.VInputPencucian oo = new View.VInputPencucian();
        
        String findK = "SELECT * FROM Kendaraan";
        String findPlat = "SELECT * FROM Kendaraan WHERE Nomor_Plat= ? ";
        String findCustomer = "SELECT * FROM Customers WHERE Nomor_Telp = ?";
        System.out.println("Inserting Kendaraan's Data...");
        try{
            PreparedStatement statementFindK = con.prepareStatement(findK);
            PreparedStatement statementFindPlat=con.prepareStatement(findPlat);
            PreparedStatement statementFindCustomer=con.prepareStatement(findCustomer);
            statementFindPlat.setString(1, o.getNoPlat());
            statementFindCustomer.setString(1, _nomor);
            ResultSet rsK = statementFindK.executeQuery();
            ResultSet rsPlat = statementFindPlat.executeQuery();
            ResultSet rsCustomer = statementFindCustomer.executeQuery(); 
            while (rsK.next())
            {
                tampungIDK=rsK.getInt("ID_Kendaraan");
            }
            IDK = tampungIDK +1;
            while (rsPlat.next())
            {
                b=1;
                tampungPlat=rsPlat.getString("Nomor_Plat");
                tampungMerk=rsPlat.getString("Merk");
                tampungModel=rsPlat.getString("Model");
                tampungJenis=rsPlat.getString("Jenis");
            }
            while (rsCustomer.next())
            {
                a=1;
                tamp=rsCustomer.getInt("ID_Customer");
                tampungC=rsCustomer.getString("Nama");
            }
            tampung = b;
            tampungA = a;
            if (b==1&&a==1)
                {
                    String findI= " select * from Kendaraan where ID_Customer = '"+tamp+"' AND Nomor_Plat = '"+"-"+"' AND Merk = '"+"-"+"' AND Model = '"+"-"+"' AND Jenis = '"+"-"+"'";
                    PreparedStatement statementFindI=con.prepareStatement(findI);
                    ResultSet rsID=statementFindI.executeQuery();
                    while (rsID.next())
                    {
                        s=1;
                    }
                    if(oo.getPlatT().equals(tampungPlat)&&oo.getMerkT().equals(tampungMerk)&&oo.getModelT().equals(tampungModel)&&oo.getJenisT().equals(tampungJenis))
                    {
                        if (s==1)
                        {
                            JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan Tersebut Telah Terdaftar Pada Database","Peringatan!!",JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Pastikan Kendaraan Tersebut Telah Melakukan Pembayaran Jasa Pencucian Kendaraannya Sebelum Dilakukan Pencucian Kembali","Peringatan!! (Untuk Menghindari Ketidak-Akuratan Data)",JOptionPane.INFORMATION_MESSAGE);
                            int y=JOptionPane.showConfirmDialog(null, "Cuci Kendaraan Lagi?","Konfirmasi",JOptionPane.YES_NO_OPTION);
                            if (y==0)
                            {
                                String sqlUU="UPDATE Kendaraan SET Nomor_Plat = '"+o.getNoPlat()+"', Merk = '"+o.getMerk()+"', Model = '"+o.getModel()+"',"
                                    + "Jenis = '"+o.getJenis()+"' WHERE ID_Customer = '"+tamp+"'";
                                Statement sSQPU = con.createStatement();
                                int rSQP = sSQPU.executeUpdate(sqlUU);
                                JOptionPane.showMessageDialog(null, "Selamat Data Kendaraan Berhasil Dimasukkan Kembali Kedalam Database Pencucian");
                                sSQPU.close();
                            }
                                else {}
                        }
                        else
                        {    
                            JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan Tersebut Telah Terdaftar Pada Database","Peringatan!!",JOptionPane.INFORMATION_MESSAGE);
                            JOptionPane.showMessageDialog(null, "Pastikan Kendaraan Tersebut Telah Melakukan Pembayaran Jasa Pencucian Kendaraannya Sebelum Dilakukan Pencucian Kembali","Peringatan!! (Untuk Menghindari Ketidak-Akuratan Data)",JOptionPane.INFORMATION_MESSAGE); 
                            int y=JOptionPane.showConfirmDialog(null, "Cuci Kendaraan Lagi?","Konfirmasi",JOptionPane.YES_NO_OPTION);
                            if (y==0)
                            {
                                String sqp="insert into Kendaraan(ID_Kendaraan,ID_Customer,Nomor_Plat,Merk,Model,Jenis) Values('"+IDK+"','"+tamp+
                                        "','"+o.getNoPlat()+"','"+o.getMerk()+"','"+o.getModel()+"','"+o.getJenis()+"')";
                                Statement sSQP = con.createStatement();
                                int rSQP = sSQP.executeUpdate(sqp);
                                JOptionPane.showMessageDialog(null, "Selamat Data Kendaraan Berhasil Dimasukkan Kembali Kedalam Database Pencucian");
                                sSQP.close();
                            }
                            else {}
                        }
                    }
                    else JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan = "+tampungPlat+" Tidak Sesuai Dengan Data Kendaraannya!!! Yaitu : Merk Kendaraan =  '"+tampungMerk+"'    Model Kendaraan = '"+tampungModel+"'    Jenis Kendaraan = '"+tampungJenis+"'","Kesalahan Pada Penginputan Data Kendaraan!!",JOptionPane.ERROR_MESSAGE);
                }
            if (b==0&&a==1)
                {
                    String findI= " select * from Kendaraan where ID_Customer = '"+tamp+"' AND Nomor_Plat = '"+"-"+"' AND Merk = '"+"-"+"' AND Model = '"+"-"+"' AND Jenis = '"+"-"+"'";
                    PreparedStatement statementFindI=con.prepareStatement(findI);
                    ResultSet rsI=statementFindI.executeQuery();
                    while (rsI.next())
                    {
                        si=1;
                    }
                    if (si==1)
                    {
                        String sql="UPDATE Kendaraan SET Nomor_Plat = '"+o.getNoPlat()+"', Merk = '"+o.getMerk()+"', Model = '"+o.getModel()+"',"
                                + "Jenis = '"+o.getJenis()+"' WHERE ID_Customer = '"+tamp+"'";
                        Statement statement=con.createStatement();
                        int result=statement.executeUpdate(sql);
                        JOptionPane.showMessageDialog(null, "Selamat Data Kendaraan Berhasil Dimasukkan kedalam database");
                        System.out.println("Success\n");
                        statement.close();
                    }
                    else
                    {
                        String sqpS="insert into Kendaraan(ID_Kendaraan,ID_Customer,Nomor_Plat,Merk,Model,Jenis) Values('"+IDK+"','"+tamp+
                                    "','"+o.getNoPlat()+"','"+o.getMerk()+"','"+o.getModel()+"','"+o.getJenis()+"')";
                        Statement sSQPS = con.createStatement();
                        int rSQP = sSQPS.executeUpdate(sqpS);
                        JOptionPane.showMessageDialog(null, "Selamat Data Kendaraan Berhasil Dimasukkan kedalam database");
                        sSQPS.close();
                    }
                }
            if (a==1){}
            else
                {
                    JOptionPane.showMessageDialog(null, "Customer Belum Menjadi Member","Kesalahan Pada Nomor Handphone Customer!!",JOptionPane.ERROR_MESSAGE);
                } 
            statementFindPlat.close();
            statementFindCustomer.close();
        }
        catch(Exception Ex){
            System.out.println("Error inserting Kendaraan's data...\n");
            System.out.println(Ex);
        }
    }
    
    public void insertCustomer(Customer o){
        int b=0;
        int c=0;
        int k=0;
        int IDC=0;
        int IDK=0;
        
        Date HariSekarang = new Date();
        SimpleDateFormat ft = new SimpleDateFormat ("E yyyy-MM-dd 'Pada' hh:mm:ss a");
        
        String findAll = "SELECT * FROM Customers";
        String findAllK = "SELECT * FROM Kendaraan";
        String find = "SELECT Nomor_Telp FROM Customers WHERE Nomor_Telp = ?";
        System.out.println("Inserting Customer's Data...");
        try{
            PreparedStatement statementFindAll = con.prepareStatement(findAll);
            PreparedStatement statementFindAllK = con.prepareStatement(findAllK);
            PreparedStatement statementFind = con.prepareStatement(find);
            statementFind.setString(1, o.getNoTelp());
            ResultSet rsAll = statementFindAll.executeQuery();
            ResultSet rsAllK = statementFindAllK.executeQuery();
            ResultSet rs = statementFind.executeQuery();
            while (rsAllK.next())
            {
                k=rsAllK.getInt("ID_Kendaraan");
            }
            while (rsAll.next())
            {
                c=rsAll.getInt("ID_Customer");
            }
            while (rs.next())
            {
                b=1;
            }
            tampung=b;
            if (b==1)
            {}
            else
            {
                IDC=c+1;
                IDK=k+1;
                String sql="INSERT INTO Customers(ID_Customer,Nama,Nomor_Telp,Alamat,Tanggal_Daftar) VALUES('"+IDC+"','"+o.getNama()+"','"+
                o.getNoTelp()+"','"+o.getAlamat()+"','"+ft.format(HariSekarang)+"')";
                String sqlK="insert into Kendaraan(ID_Kendaraan,ID_Customer,Nomor_Plat,Merk,Model,Jenis) values('"+IDK+"','"+IDC+"','"
                        +"-"+"','"+"-"+"','"+"-"+"','"+"-"+"')";
                Statement statement=con.createStatement();
                int result=statement.executeUpdate(sql);
                int re=statement.executeUpdate(sqlK);
                JOptionPane.showMessageDialog(null, "Pendaftaran Customer Berhasil!!");
                statement.close();
            }
        }
        catch(Exception Ex){
            System.out.println("Error inserting Customer's data...\n");
            System.out.println(Ex);
        }
    }
    
    public void hapusCustomer(String _nama, String _nomor){
        String find = "SELECT * FROM Customers WHERE Nama = ? AND Nomor_Telp = ?";
        int tamp=0;
        int b=0;
        System.out.println("Deleting Customer's Data...");
        try{
            PreparedStatement statementFind = con.prepareStatement(find);
            statementFind.setString(1, _nama);
            statementFind.setString(2, _nomor);
            ResultSet rs = statementFind.executeQuery();
            while (rs.next())
            {
                b=1;
                tamp=rs.getInt("ID_Customer");
            }
            tampung=b;
            if (b==1)
            {
                String sqlT="delete from Transaksi Where ID_CustomerBayar = '"+tamp+"'";
                String sqlK="delete from Kendaraan where ID_Customer = '"+tamp+"'";
                String sql="DELETE FROM Customers WHERE Nama = '"+_nama+"' AND Nomor_Telp = '"+_nomor+"'";
                Statement statement=con.createStatement();
                int resultT=statement.executeUpdate(sqlT);
                int resultK=statement.executeUpdate(sqlK);
                int result=statement.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Penghapusann Data Customer Berhasil!!");
                statement.close();
            }
            else
            {}
        }
        catch(Exception Ex){
            System.out.println("Error deleting Customer's data...\n");
            System.out.println(Ex);
        }
    }
    
    public void matching(String _username, String _password){
        String sql="SELECT Username,Password FROM Kasir WHERE Username = ? AND Password = ?";
        int b = 0;
        System.out.println("Finding Kasir's data...");
        try{
            PreparedStatement statement=con.prepareStatement(sql);
            statement.setString(1, _username);
            statement.setString(2, _password);
            ResultSet result=statement.executeQuery();
            while (result.next())
            {
                    b=1;
            }
            tampung=b;
                if (b==1)
                {
                    JOptionPane.showMessageDialog(null, "Login Berhasil!!");
                } 
                else JOptionPane.showMessageDialog(null, "Login Gagal!!!, Username atau Password Salah","Kesalahan",JOptionPane.ERROR_MESSAGE);
            statement.close();
        }
        catch(Exception Ex){
            System.out.println("Error Finding Kasir's data...\n");
            System.out.println(Ex);
        }
    }
    
    public void updateGantiPassword(String _user, String _passL, String _passB){
        String find = "SELECT Username,Password FROM Kasir WHERE Username = ? AND Password = ?";
        int b = 0;
        System.out.println("Changing Password...");
        try{
            PreparedStatement statementFind=con.prepareStatement(find);
            Statement statement=con.createStatement();
            statementFind.setString(1, _user);
            statementFind.setString(2, _passL);
            ResultSet resultFind=statementFind.executeQuery();
            while (resultFind.next())
            {
                    b=1;
            }
            tampung=b;
                if (b==1)
                {
                    String sql="UPDATE Kasir SET Password = '"+_passB+"' WHERE Password = '"+_passL+"' AND Username = '"+_user+"'";
                    int result=statement.executeUpdate(sql);
                    JOptionPane.showMessageDialog(null, "Ubah Password Berhasil!!!");
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Ubah Password Gagal!!, Username atau Password Lama anda Salah","Kesalahan!!",JOptionPane.ERROR_MESSAGE);
                }
            statement.close();
        }
        catch(Exception Ex){
            JOptionPane.showMessageDialog(null, "Password Lama Atau Username Salah","Kesalahan!!",JOptionPane.ERROR_MESSAGE);
            System.out.println(Ex);
        }
    }
    
    public void tampilKendaraan(String _noPlat)
    {
        int j=0;
        int b = 0;
        String tampungMerk="";
        String tampungModel="";
        String tampungPlat = "";
        String tampungJenis="";

        
        View.VPembayaran oo = new View.VPembayaran();
        
        String findPlat = "SELECT * FROM Kendaraan WHERE Nomor_Plat= ? ";
        System.out.println("Selecting Kendaraan's Data");
        try{
            PreparedStatement statementFindPlat=con.prepareStatement(findPlat);

            statementFindPlat.setString(1, _noPlat);
            
            ResultSet rsPlat = statementFindPlat.executeQuery();

            while (rsPlat.next())
            {
                b=1;
                tampungPlat=rsPlat.getString("Nomor_Plat");
                tampungMerk=rsPlat.getString("Merk");
                tampungModel=rsPlat.getString("Model");
                tampungJenis=rsPlat.getString("Jenis");
            }

            tampungPlatK=tampungPlat;
            tampungMerkK=tampungMerk;
            tampungModelK=tampungModel;
            tampungJenisK=tampungJenis;
            
            if (b==1)
                {
                    if(oo.getJenisTS().equals(tampungJenis)&&oo.getPlatTS().equals(tampungPlat))
                    {
                        j=1;
                    }
                    else JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan = "+tampungPlat+" Tidak Sesuai Dengan Jenis Kendaraannya = '"+tampungJenis+"' !!","Kesalahan Pada Jenis Kendaraan!!",JOptionPane.ERROR_MESSAGE);
                } 
            else
                {
                    JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan Tidak Ditemukan Di Database Pencucian (Inputkan Pencucian Kendaraan Tersebut Terlebih Dahulu!!)","Kesalahan (Kurang Teliti!!)",JOptionPane.ERROR_MESSAGE);
                }
            tampung=j;
            statementFindPlat.close();
        }
        catch(Exception Ex){
            System.out.println("Error Showing Kendaraan's data...\n");
            System.out.println(Ex);
        }
    }
    
    public void tampilKendaraanCustomer(String _noHP,String _noPlat)
    {
        int j=0;
        int a=0;
        int b = 0;
        int f =0;
        
        int tampungCC=0;
        int tampungCCP=0;
        
        String tampungHP="";
        String tampungMerk="";
        String tampungModel="";
        String tampungPlat = "";
        String tampungJenis="";

        
        View.VPembayaran oo = new View.VPembayaran();
        
        String findC="SELECT * FROM Customers WHERE Nomor_Telp = ?";
        String findPlat = "SELECT * FROM Kendaraan WHERE Nomor_Plat= ? ";
        System.out.println("Selecting Kendaraan's Data");
        try{
            PreparedStatement statementFindPlat=con.prepareStatement(findPlat);
            PreparedStatement statementFindC=con.prepareStatement(findC);
            
            statementFindC.setString(1, _noHP);
            statementFindPlat.setString(1, _noPlat);
            
            ResultSet rsC = statementFindC.executeQuery();
            ResultSet rsPlat = statementFindPlat.executeQuery();

            while (rsC.next())
            {
                a=1;
                tampungHP=rsC.getString("Nomor_Telp");
                tampungCC=rsC.getInt("ID_Customer");
            }
            while (rsPlat.next())
            {
                b=1;
                tampungCCP=rsPlat.getInt("ID_Customer");
                if (tampungCC==tampungCCP)
                {
                    f=1;
                    tampungPlat=rsPlat.getString("Nomor_Plat");
                    tampungMerk=rsPlat.getString("Merk");
                    tampungModel=rsPlat.getString("Model");
                    tampungJenis=rsPlat.getString("Jenis");
                }
            }

            tampungPlatK=tampungPlat;
            tampungMerkK=tampungMerk;
            tampungModelK=tampungModel;
            tampungJenisK=tampungJenis;

            if (b==1&&a==1&&f==1)
                {
                    if(oo.getJenisTS().equals(tampungJenis)&&oo.getPlatTS().equals(tampungPlat))
                    {
                        j=1;
                    }
                    else 
                    {
                        JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan = "+tampungPlat+" Tidak Sesuai Dengan Jenis Kendaraannya!!!, Jenis Kendaraan = '"+tampungJenis+"'","Kesalahan Pada Jenis Kendaraan!!",JOptionPane.ERROR_MESSAGE);
                    }
                } 
            else
                {
                    JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan dan Nomor HP Customer Tidak Cocok atau Tidak Ditemukan Di Database Pencucian (Inputkan Pencucian Kendaraan Tersebut Terlebih Dahulu!!)","Kesalahan (Kurang Teliti!!)",JOptionPane.ERROR_MESSAGE);
                }
            tampung=j;

            statementFindPlat.close();
        }
        catch(Exception Ex){
            System.out.println("Error Showing Kendaraan's data...\n");
            System.out.println(Ex);
        }
    }
    
    public void pembayaranKendaraan(String _noPlat)
    {
        int IDK = 0;
        int IDC = 0;
        int b = 0;
        int c=0;
        
        String tampungPlat="";
        String tampungJenis="";
        String tampungMerk="";
        String tampungModel="";
        
        int tampungIDK=0;
        int tampungIDCC=0;
        int tampungIDKK=0;
        
        View.VPembayaran oo = new View.VPembayaran();
        
        Date HariSekarang = new Date( );
        SimpleDateFormat ft = new SimpleDateFormat ("E yyyy-MM-dd 'Pada' hh:mm:ss a");

        String findPlat = "SELECT * FROM Kendaraan WHERE Nomor_Plat= ? ";
        try{

            PreparedStatement statementFindPlat=con.prepareStatement(findPlat);

            statementFindPlat.setString(1, _noPlat);
            
            ResultSet rsPlat = statementFindPlat.executeQuery();

            while (rsPlat.next())
            {
                b=1;
                tampungIDKK=rsPlat.getInt("ID_Kendaraan");
                tampungIDCC=rsPlat.getInt("ID_Customer");
                tampungPlat=rsPlat.getString("Nomor_Plat");
                tampungMerk=rsPlat.getString("Merk");
                tampungModel=rsPlat.getString("Model");
                tampungJenis=rsPlat.getString("Jenis");
            }
            IDK = tampungIDK+1;
            
            tampung = b;
            if (b==1)
                {
                   if(oo.getJenisTS().equals(tampungJenis)&&oo.getPlatTS().equals(tampungPlat))
                    {
                        int y=JOptionPane.showConfirmDialog(null, "Yakin Untuk Melakukan Pembayaran?","Konfirmasi",JOptionPane.YES_NO_OPTION);
                        if (y==0)
                        {
                            c=1;
                            tampungA=c;
                            if (oo.getJenisTS().equals("Mobil"))
                            {
                                String sqlCus="insert into Transaksi(ID_Kasir,ID_Kendaraan,ID_CustomerBayar,Tanggal_Bayar,Harga) Values ('"+1000+"','"+tampungIDKK+"','"+tampungIDCC+"','"+ft.format(HariSekarang)+"','"+20000+"')";
                                Statement sSQP = con.createStatement();
                                int resC = sSQP.executeUpdate(sqlCus);
                                JOptionPane.showMessageDialog(null, "Selamat !!, Pembayaran Kendaraan Berhasil");
                                sSQP.close();
                            }
                            if (oo.getJenisTS().equals("Motor"))
                            {
                                String sqlCus="insert into Transaksi(ID_Kasir,ID_Kendaraan,ID_CustomerBayar,Tanggal_Bayar,Harga) Values ('"+1000+"','"+tampungIDKK+"','"+tampungIDCC+"','"+ft.format(HariSekarang)+"','"+12000+"')";
                                Statement sSQP = con.createStatement();
                                int resC = sSQP.executeUpdate(sqlCus);
                                JOptionPane.showMessageDialog(null, "Selamat !!, Pembayaran Kendaraan Berhasil");
                                sSQP.close();
                            }  
                        }
                        else {}
                    }
                    else JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan = "+tampungPlat+" Tidak Sesuai Dengan Jenis Kendaraannya!!!, Jenis Kendaraan = '"+tampungJenis+"'","Kesalahan Pada Jenis Kendaraan!!",JOptionPane.ERROR_MESSAGE);
                } 
            else
                {
                    JOptionPane.showMessageDialog(null, "Pembayaran Gagal!!!, Nomor Plat Kendaraan Tidak Ditemukan Di Database Pencucian (Inputkan Pencucian Kendaraan Tersebut Terlebih Dahulu!!)","Kesalahan (Kurang Teliti!!)",JOptionPane.ERROR_MESSAGE);
                }
            statementFindPlat.close();
        }
        catch(Exception Ex){
            System.out.println("Error inserting the data...\n");
            System.out.println(Ex);
        }
    }
    
     public void pembayaranKendaraanC(String _noHp, String _noPlat)
    {
        int IDK = 0;
        int IDC = 0;
        int b = 0;
        int c=0;
        int a=0;
        int f=0;
        
        int tampungIDCus=0;
        int tampungPCus=0;
        
        String tampungHP="";
        String tampungPlat="";
        String tampungJenis="";
        
        int tampungIDK=0;
        int tampungIDCC=0;
        int tampungIDKK=0;
        
        View.VPembayaran oo = new View.VPembayaran();
        
        Date HariSekarang = new Date( );
        SimpleDateFormat ft = new SimpleDateFormat ("E yyyy-MM-dd 'Pada' hh:mm:ss a");

        String findC="select * From Customers Where Nomor_Telp = ?";
        String findPlat = "SELECT * FROM Kendaraan WHERE Nomor_Plat= ? ";
        try{

            PreparedStatement statementFindPlat=con.prepareStatement(findPlat);
            PreparedStatement statementFindC=con.prepareStatement(findC);

            statementFindPlat.setString(1, _noPlat);
            statementFindC.setString(1, _noHp);
            
            ResultSet rsPlat = statementFindPlat.executeQuery();
            ResultSet rsC = statementFindC.executeQuery();
            
            while (rsC.next())
            {
                a=1;
                tampungIDCus=rsC.getInt("ID_Customer");
                tampungHP=rsC.getString("Nomor_Telp");
            }
            while (rsPlat.next())
            {
                b=1;
                tampungPCus=rsPlat.getInt("ID_Customer");
                if (tampungIDCus==tampungPCus)
                {
                    f=1;
                    tampungIDKK=rsPlat.getInt("ID_Kendaraan");
                    tampungIDCC=rsPlat.getInt("ID_Customer");
                    tampungPlat=rsPlat.getString("Nomor_Plat");
                    tampungJenis=rsPlat.getString("Jenis");
                }
            }
            IDK = tampungIDK+1;
            
            tampung = b;
            if (b==1&&a==1&&f==1)
                {
                   if(oo.getJenisTS().equals(tampungJenis)&&oo.getPlatTS().equals(tampungPlat))
                    {
                        int y=JOptionPane.showConfirmDialog(null, "Yakin Untuk Melakukan Pembayaran?","Konfirmasi",JOptionPane.YES_NO_OPTION);
                        if (y==0)
                        {
                            c=1;
                            tampungA=c;
                            if (oo.getJenisTS().equals("Mobil"))
                            {
                                String sqlCus="insert into Transaksi(ID_Kasir,ID_Kendaraan,ID_CustomerBayar,Tanggal_Bayar,Harga,Tampung_IDCus) Values ('"+1000+"','"+tampungIDKK+"','"+tampungIDCC+"','"+ft.format(HariSekarang)+"','"+20000+"','"+tampungIDCC+"')";
                                Statement sSQP = con.createStatement();
                                int resC = sSQP.executeUpdate(sqlCus);
                                JOptionPane.showMessageDialog(null, "Selamat !!, Pembayaran Kendaraan Berhasil");
                                sSQP.close();
                            }
                            if (oo.getJenisTS().equals("Motor"))
                            {
                                String sqlCus="insert into Transaksi(ID_Kasir,ID_Kendaraan,ID_CustomerBayar,Tanggal_Bayar,Harga) Values ('"+1000+"','"+tampungIDKK+"','"+tampungIDCC+"','"+ft.format(HariSekarang)+"','"+12000+"')";
                                Statement sSQP = con.createStatement();
                                int resC = sSQP.executeUpdate(sqlCus);
                                JOptionPane.showMessageDialog(null, "Selamat !!, Pembayaran Kendaraan Berhasil");
                                sSQP.close();
                            }  
                        }
                        else {}
                    }
                   else JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan = "+tampungPlat+" Tidak Sesuai Dengan Jenis Kendaraannya!!!, Jenis Kendaraan = '"+tampungJenis+"'","Kesalahan Pada Jenis Kendaraan!!",JOptionPane.ERROR_MESSAGE);
                } 
            else
                {
                    JOptionPane.showMessageDialog(null, "Nomor Plat Kendaraan dan Nomor HP Customer Tidak Cocok atau Tidak Ditemukan Di Database Pencucian (Inputkan Pencucian Kendaraan Tersebut Terlebih Dahulu!!)","Kesalahan (Kurang Teliti!!)",JOptionPane.ERROR_MESSAGE);
                }
            statementFindPlat.close();
        }
        catch(Exception Ex){
            System.out.println("Error Showing Kendaraan's data...\n");
            System.out.println(Ex);
        }
    }
     
    public int getTampung()
    {
        return tampung;
    }   
    public int getTampungA()
    {
        return tampungA;
    }
    
    public String getPlatK()
    {
        return tampungPlatK;
    }
    public String getMerkK()
    {
        return tampungMerkK;
    }
    public String getModelK()
    {
        return tampungModelK;
    }
    public String getJenisK()
    {
        return tampungJenisK;
    }
}