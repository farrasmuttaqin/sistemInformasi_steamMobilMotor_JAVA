/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

/**
 *
 * @author farras
 */
public class ControlGantiPassword {
    
    public Control.DAO d = new Control.DAO();
    
    public ControlGantiPassword(){}
    
    public void UpdateGantiPassword(String _user,String _passL, String _passB)
    {
            d.makeConnection();
            d.updateGantiPassword(_user, _passL, _passB);
            d.closeConnection();
    }
}
