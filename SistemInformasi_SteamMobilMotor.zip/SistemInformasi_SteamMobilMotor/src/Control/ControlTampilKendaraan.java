/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Control;

/**
 *
 * @author farras
 */
public class ControlTampilKendaraan {
    public Control.DAO d = new Control.DAO();
    
    public ControlTampilKendaraan(){}
    
    public void tampilK(String _noPlat)
    {
            d.makeConnection();
            d.tampilKendaraan(_noPlat);
            d.closeConnection();
    }
}
